from config import logger
from utils import create_webdriver

class BrowserController:
    def __init__(self, incognito=False):
        # Only create one instance of the driver using the utility function
        self.driver = create_webdriver(incognito)

    def navigate_to_local_google(self):
        try:
            self.driver.get('https://www.google.com')
        except Exception as e:
            logger.error(f"Failed to navigate to local Google homepage: {e}")

    def close_browser(self):
        try:
            self.driver.quit()
            logger.info("Browser closed.")
        except Exception as e:
            logger.error(f"Failed to close browser: {e}")
