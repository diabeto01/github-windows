import os
import sys
from pathlib import Path
from typing import Optional
import random
import undetected_chromedriver as uc
from fake_useragent import UserAgent
from config import logger
from geolocation_db import GeolocationDB

def get_random_user_agent_string() -> str:
    ua = UserAgent()
    user_agent_string = ua.random
    logger.info(f"User agent: {user_agent_string}")
    return user_agent_string

def create_webdriver(incognito: Optional[bool] = False) -> uc.Chrome:
    user_agent_str = get_random_user_agent_string()
    chrome_options = uc.ChromeOptions()
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--ignore-ssl-errors")
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_argument("--no-first-run")
    chrome_options.add_argument("--no-service-autorun")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_argument(f"--user-agent={user_agent_str}")
    chrome_options.add_argument("--disable-3d-apis")  # Disable WebGL
    chrome_options.add_argument("--disable-rtc-smpte-tc")  # Disable WebRTC
    chrome_options.add_argument("--disable-javascript")

    if incognito:
        chrome_options.add_argument("--incognito")
        # Path to the NordVPN extension .crx file
        nordvpn_extension_path = 'NordVPN.crx'
        chrome_options.add_extension(nordvpn_extension_path)
    else:
        chrome_options.add_argument("--headless")  # Enable headless mode by default

    # Specify the Chrome version compatible with the installed browser version
    driver = uc.Chrome(options=chrome_options)
    return driver
