import requests

def test_proxy(proxy_dict):
    url = "http://httpbin.org/ip"

    try:
        response = requests.get(url, proxies=proxy_dict, timeout=10)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx and 5xx)
    except requests.RequestException as e:
        print(f"An error occurred: {e}")
        return False

    data = response.json()
    print(f"IP address as seen by httpbin.org: {data['origin']}")
    return True

# Replace the following line with your proxy details
proxy_dict = {
    "http": "socks5://egbobD7ALtEPdm2g971Wsfss:9g43btWPnN3ugyRAD9YZcvVH@amsterdam.nl.socks.nordhold.net:1080",
    "https": "socks5://egbobD7ALtEPdm2g971Wsfss:9g43btWPnN3ugyRAD9YZcvVH@amsterdam.nl.socks.nordhold.net:1080",
}

if __name__ == "__main__":
    if test_proxy(proxy_dict):
        print("The proxy is working fine!")
    else:
        print("There was a problem with the proxy.")
