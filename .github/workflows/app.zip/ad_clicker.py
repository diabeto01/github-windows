import logging
import time
from config import logger
from browser_controller import BrowserController
from argparse import ArgumentParser
from selenium.common.exceptions import WebDriverException

def get_arg_parser() -> ArgumentParser:
    """Get argument parser"""
    arg_parser = ArgumentParser()
    arg_parser.add_argument("--incognito", action="store_true", help="Run in incognito mode")
    return arg_parser

def main():
    """Entry point for the tool"""
    arg_parser = get_arg_parser()
    args = arg_parser.parse_args()

    browser_controller = BrowserController(incognito=args.incognito)

    try:
        logger.info("Browser is running. Close it manually to exit.")
        while True:  # Keeps browser running in a loop
            try:
                # Check if any browser windows are still open
                if not browser_controller.driver.window_handles:
                    logger.info("Browser has been closed, exiting.")
                    break  # Exit the loop if no browser windows are open
            except WebDriverException:
                logger.info("Browser was closed manually.")
                break
            time.sleep(1)  # Sleep to prevent tight loop, adjust as needed

    except KeyboardInterrupt:
        logger.info("Terminating the browser...")

    finally:
        # Ensure the browser is closed properly
        try:
            browser_controller.close_browser()
        except WebDriverException:
            logger.info("Browser already closed.")

if __name__ == "__main__":
    main()
