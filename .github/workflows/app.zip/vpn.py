import subprocess
import requests
from config import logger

def connect_to_vpn() -> str:
    """Connect to NordVPN and return the IP address."""
    result = subprocess.run(["nordvpn", "connect"], capture_output=True, text=True)
    if result.returncode == 0:
        logger.info("Connected to VPN")
        return get_current_ip()
    else:
        logger.error(f"Failed to connect to VPN: {result.stderr}")
        return None

def disconnect_from_vpn() -> None:
    """Disconnect from NordVPN."""
    result = subprocess.run(["nordvpn", "disconnect"], capture_output=True, text=True)
    if result.returncode == 0:
        logger.info("Disconnected from VPN")
    else:
        logger.error(f"Failed to disconnect from VPN: {result.stderr}")

def get_current_ip() -> str:
    """Get the current IP address."""
    try:
        response = requests.get("http://api.ipify.org")
        response.raise_for_status()
        return response.text
    except requests.RequestException as e:
        logger.error(f"Failed to retrieve IP address: {e}")
        return None
